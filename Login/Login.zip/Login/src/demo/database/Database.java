package demo.database;public interface Database {
}
