package demo.database;

import demo.domain.User;

public class FileHandler {

    public User findUser(String name, String password){

        //TODO Change later to real code
        return new User("John Smith", "1234");
    }
}
